package gg.bayes;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class JavaCodeChallengeApplication {

    public static void main(String[] args) {
        SpringApplication.run(JavaCodeChallengeApplication.class, args);
    }
}
